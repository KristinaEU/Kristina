# Visual Scene Maker EXPERIMENTAL


######(c) 2003-15. All rights reserved
------------------------------------------------------------------------------
Branch of Visual **SceneMaker** reserved for bleeding edge bug fixes and enhancements.

This version is experimental. **DO NOT USE**

For a stable version check our [RELEASE BRANCH](https://github.com/SceneMaker/VisualSceneMaker/tree/RELEASE)
------------------------------------------------------------------------------

##### For more information, visit the website 
##[scenemaker.dfki.de](http://scenemaker.dfki.de)
------------------------------------------------------------------------------

 
