package de.dfki.vsm.editor.action;

//package de.dfki.vsm.editor.action;
//
//import de.dfki.vsm.editor.dialog.ModifySceneFlowDialog;
//import de.dfki.vsm.mod.sceneflow.SceneFlow;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
///**
// * @author Not me
// */
//public class ModifySceneFlowAction {
//
//    private SceneFlow mSceneFlow = null;
//
//    public ModifySceneFlowAction(SceneFlow sceneFlow) {
//        mSceneFlow = sceneFlow;
//    }
//
//    public ActionListener getActionListener() {
//        return new ActionListener() {
//
//            public void actionPerformed(ActionEvent e) {
//                ModifySceneFlowDialog dialog = new ModifySceneFlowDialog(mSceneFlow);
//                mSceneFlow = dialog.run();
//            }
//        };
//    }
//}




