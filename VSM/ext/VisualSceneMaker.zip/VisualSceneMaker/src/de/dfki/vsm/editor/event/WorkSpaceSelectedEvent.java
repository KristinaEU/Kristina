package de.dfki.vsm.editor.event;

//~--- non-JDK imports --------------------------------------------------------

import de.dfki.vsm.util.evt.EventObject;

/**
 *     @author Martin Fallas
 */
public class WorkSpaceSelectedEvent extends EventObject {
    public WorkSpaceSelectedEvent(Object source) {
        super(source);
    }
}
