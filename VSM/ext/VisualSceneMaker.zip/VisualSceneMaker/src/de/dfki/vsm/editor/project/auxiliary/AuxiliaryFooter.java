package de.dfki.vsm.editor.project.auxiliary;

import javax.swing.JPanel;

/**
 * @author Gregor Mehlmann
 */
public class AuxiliaryFooter extends JPanel {

}
