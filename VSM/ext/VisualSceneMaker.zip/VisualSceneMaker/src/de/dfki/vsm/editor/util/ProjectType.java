package de.dfki.vsm.editor.util;

public enum ProjectType { SM3, VSM }
