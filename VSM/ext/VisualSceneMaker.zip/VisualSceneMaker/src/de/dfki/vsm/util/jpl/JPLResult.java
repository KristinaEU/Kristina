package de.dfki.vsm.util.jpl;

//~--- JDK imports ------------------------------------------------------------

import java.util.HashMap;
import java.util.LinkedList;

/**
 *
 * @author Not me
 */
public class JPLResult extends LinkedList<HashMap<String, String>> {
    public JPLResult(final String query) {}
}
